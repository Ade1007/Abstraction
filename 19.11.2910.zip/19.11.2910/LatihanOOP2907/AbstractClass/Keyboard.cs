﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstraction.AbstractClass
{
   public class Keyboard : HardwareKomputer
    {
        public override void Fungsi()
        {
            Console.WriteLine("Keyboard berfungsi untuk membantu user dalam memberikan dan juga memasukan perintah agar dapat dijalankan oleh sistem komputer");
            Console.WriteLine("Dan juga untuk mengetik huruf, angka, dan simbol-simbol lainnya");
        }
    }
}
