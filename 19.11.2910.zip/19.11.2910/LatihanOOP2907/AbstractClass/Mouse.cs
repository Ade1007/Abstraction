﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstraction.AbstractClass
{
    public class Mouse : HardwareKomputer
    {
        public override void Fungsi()
        {
            Console.WriteLine("Mouse berfungsi untuk mengatur pergerakan kursor secara cepat ");
            Console.WriteLine("Dan untuk memberikan suatu perintah dengan hanya menekan tombol pada mouse komputer");
        }
    }
}
