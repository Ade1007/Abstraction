﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstraction.Interface
{
    public interface IHardwareKomputer
    {
        void Fungsi();
    }
}
