﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstraction.Interface
{
    public class Keyboard : IHardwareKomputer
    {
        public void Fungsi()
        {
            Console.WriteLine("Keyboard berfungsi untuk membantu user dalam memberikan dan juga memasukan perintah agar dapat dijalankan oleh sistem komputer");
            Console.WriteLine("Dan juga untuk mengetik huruf, angka, dan simbol-simbol lainnya");
        }
    }
}
